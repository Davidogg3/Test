import React, { useCallback } from 'react';
import ReactFlow, {
  Background,
  Controls,
  Panel,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { useStore } from './store';
import { CustomNode } from './components/CustomNode';
import { Plus, Trash2 } from 'lucide-react';

const nodeTypes = {
  customNode: CustomNode,
};

function App() {
  const {
    nodes,
    edges,
    onNodesChange,
    onEdgesChange,
    onConnect,
    addNode,
    deleteSelected,
  } = useStore();

  const handleAddNode = useCallback((type: string) => {
    addNode(type, {
      x: Math.random() * 500,
      y: Math.random() * 500,
    });
  }, [addNode]);

  return (
    <div className="w-screen h-screen">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        fitView
      >
        <Background />
        <Controls />
        
        <Panel position="top-left" className="flex gap-2">
          <button
            onClick={() => handleAddNode('employee')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            <Plus size={16} /> Employee
          </button>
          <button
            onClick={() => handleAddNode('segment')}
            className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          >
            <Plus size={16} /> Segment
          </button>
          <button
            onClick={() => handleAddNode('account')}
            className="flex items-center gap-2 px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600"
          >
            <Plus size={16} /> Account
          </button>
          <button
            onClick={deleteSelected}
            className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
          >
            <Trash2 size={16} /> Delete
          </button>
        </Panel>
      </ReactFlow>
    </div>
  );
}

export default App;