export interface NodeData {
  type: 'employee' | 'segment' | 'account';
  label?: string;
  role?: string;
  revenue: number;
  color?: string;
}

export interface FlowState {
  nodes: any[];
  edges: any[];
  addNode: (type: string, position: { x: number; y: number }) => void;
  updateNodeData: (id: string, data: Partial<NodeData>) => void;
  onNodesChange: (changes: any) => void;
  onEdgesChange: (changes: any) => void;
  onConnect: (connection: any) => void;
  deleteSelected: () => void;
}