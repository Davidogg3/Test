import { create } from 'zustand';
import {
  Connection,
  Edge,
  EdgeChange,
  Node,
  NodeChange,
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
} from 'reactflow';
import { NodeData, FlowState } from './types';

const colors = [
  'bg-blue-100',
  'bg-green-100',
  'bg-purple-100',
  'bg-yellow-100',
  'bg-pink-100',
  'bg-orange-100',
];

let nodeId = 1;
let colorIndex = 0;

const findParentSegmentColor = (
  nodes: Node<NodeData>[],
  edges: Edge[],
  nodeId: string
): string | undefined => {
  // Find all incoming edges to this node
  const incomingEdges = edges.filter(edge => edge.target === nodeId);
  
  for (const edge of incomingEdges) {
    const parentNode = nodes.find(node => node.id === edge.source);
    if (parentNode?.data.type === 'segment') {
      return parentNode.data.color;
    } else if (parentNode) {
      // Recursively check for segment color through the parent
      const segmentColor = findParentSegmentColor(nodes, edges, parentNode.id);
      if (segmentColor) return segmentColor;
    }
  }
  
  return undefined;
};

const updateNodeColors = (nodes: Node<NodeData>[], edges: Edge[]): Node<NodeData>[] => {
  return nodes.map(node => {
    if (node.data.type !== 'segment') {
      const segmentColor = findParentSegmentColor(nodes, edges, node.id);
      return {
        ...node,
        data: { ...node.data, color: segmentColor }
      };
    }
    return node;
  });
};

const calculateAccountRevenue = (
  nodes: Node<NodeData>[],
  edges: Edge[],
  employeeId: string
): number => {
  const connectedAccountIds = edges
    .filter(edge => edge.source === employeeId)
    .map(edge => edge.target);

  return nodes
    .filter(node => connectedAccountIds.includes(node.id) && node.data.type === 'account')
    .reduce((sum, node) => sum + (node.data.revenue || 0), 0);
};

const calculateSegmentRevenue = (
  nodes: Node<NodeData>[],
  edges: Edge[],
  segmentId: string
): number => {
  const connectedEmployeeIds = edges
    .filter(edge => edge.source === segmentId)
    .map(edge => edge.target);

  return nodes
    .filter(node => 
      connectedEmployeeIds.includes(node.id) && 
      node.data.type === 'employee'
    )
    .reduce((sum, node) => {
      const employeeRevenue = calculateAccountRevenue(nodes, edges, node.id);
      return sum + employeeRevenue;
    }, 0);
};

const updateNodeRevenues = (nodes: Node<NodeData>[], edges: Edge[]): Node<NodeData>[] => {
  return nodes.map(node => {
    if (node.data.type === 'employee') {
      const revenue = calculateAccountRevenue(nodes, edges, node.id);
      return {
        ...node,
        data: { ...node.data, revenue }
      };
    }
    if (node.data.type === 'segment') {
      const revenue = calculateSegmentRevenue(nodes, edges, node.id);
      return {
        ...node,
        data: { ...node.data, revenue }
      };
    }
    return node;
  });
};

export const useStore = create<FlowState>((set, get) => ({
  nodes: [],
  edges: [],
  
  addNode: (type: string, position: { x: number; y: number }) => {
    const newNode: Node<NodeData> = {
      id: `node-${nodeId++}`,
      type: 'customNode',
      position,
      data: {
        type,
        label: type === 'employee' ? 'New Employee' : type === 'segment' ? 'New Segment' : 'New Account',
        role: type === 'employee' ? 'Role' : undefined,
        revenue: 0,
        color: type === 'segment' ? colors[colorIndex++ % colors.length] : undefined,
      },
    };

    set({ nodes: [...get().nodes, newNode] });
  },

  updateNodeData: (id: string, newData: Partial<NodeData>) => {
    const { nodes, edges } = get();
    let updatedNodes = nodes.map((node) => {
      if (node.id === id) {
        return {
          ...node,
          data: { ...node.data, ...newData },
        };
      }
      return node;
    });

    // Update colors and revenues
    updatedNodes = updateNodeColors(updatedNodes, edges);
    updatedNodes = updateNodeRevenues(updatedNodes, edges);
    set({ nodes: updatedNodes });
  },

  onNodesChange: (changes: NodeChange[]) => {
    const nodes = applyNodeChanges(changes, get().nodes);
    const { edges } = get();
    // Update colors and revenues
    const colorUpdatedNodes = updateNodeColors(nodes, edges);
    const updatedNodes = updateNodeRevenues(colorUpdatedNodes, edges);
    set({ nodes: updatedNodes });
  },

  onEdgesChange: (changes: EdgeChange[]) => {
    const edges = applyEdgeChanges(changes, get().edges);
    const { nodes } = get();
    // Update colors and revenues
    const colorUpdatedNodes = updateNodeColors(nodes, edges);
    const updatedNodes = updateNodeRevenues(colorUpdatedNodes, edges);
    set({ nodes: updatedNodes, edges });
  },

  onConnect: (connection: Connection) => {
    const newEdge = addEdge(connection, get().edges);
    const { nodes } = get();
    
    // Update colors and revenues
    const colorUpdatedNodes = updateNodeColors(nodes, newEdge);
    const updatedNodes = updateNodeRevenues(colorUpdatedNodes, newEdge);
    set({
      edges: newEdge,
      nodes: updatedNodes,
    });
  },

  deleteSelected: () => {
    const { nodes, edges } = get();
    const updatedNodes = nodes.filter(node => !node.selected);
    const updatedEdges = edges.filter(edge => !edge.selected);

    // Update colors and revenues after deletion
    const colorUpdatedNodes = updateNodeColors(updatedNodes, updatedEdges);
    const finalNodes = updateNodeRevenues(colorUpdatedNodes, updatedEdges);
    set({
      nodes: finalNodes,
      edges: updatedEdges,
    });
  },
}));