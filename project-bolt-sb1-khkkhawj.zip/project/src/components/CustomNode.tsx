import React, { useState } from 'react';
import { Handle, Position } from 'reactflow';
import { NodeData } from '../types';
import { useStore } from '../store';

interface CustomNodeProps {
  id: string;
  data: NodeData;
  selected: boolean;
}

export function CustomNode({ id, data, selected }: CustomNodeProps) {
  const [isEditingLabel, setIsEditingLabel] = useState(false);
  const [isEditingRole, setIsEditingRole] = useState(false);
  const [isEditingRevenue, setIsEditingRevenue] = useState(false);
  const updateNodeData = useStore(state => state.updateNodeData);

  const baseClasses = `p-4 rounded-lg shadow-md border-2 ${
    selected ? 'border-blue-500' : 'border-gray-200'
  } ${data.color || 'bg-white'}`;

  const handleDoubleClick = (field: string) => {
    switch (field) {
      case 'label':
        setIsEditingLabel(true);
        break;
      case 'role':
        setIsEditingRole(true);
        break;
      case 'revenue':
        setIsEditingRevenue(true);
        break;
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent, field: string) => {
    if (e.key === 'Enter') {
      const target = e.target as HTMLInputElement;
      const value = target.value;
      
      switch (field) {
        case 'label':
          updateNodeData(id, { label: value });
          setIsEditingLabel(false);
          break;
        case 'role':
          updateNodeData(id, { role: value });
          setIsEditingRole(false);
          break;
        case 'revenue':
          const numValue = parseFloat(value) || 0;
          updateNodeData(id, { revenue: numValue });
          setIsEditingRevenue(false);
          break;
      }
    }
  };

  return (
    <div className={baseClasses}>
      <Handle type="target" position={Position.Top} />
      
      <div className="flex flex-col items-center gap-2 min-w-[200px]">
        {data.type === 'employee' && (
          <div
            onDoubleClick={() => handleDoubleClick('role')}
            className="font-medium"
          >
            {isEditingRole ? (
              <input
                type="text"
                defaultValue={data.role}
                onKeyPress={(e) => handleKeyPress(e, 'role')}
                autoFocus
                className="text-center bg-transparent border-b"
              />
            ) : (
              data.role
            )}
          </div>
        )}

        <div
          onDoubleClick={() => handleDoubleClick('label')}
          className="font-bold"
        >
          {isEditingLabel ? (
            <input
              type="text"
              defaultValue={data.label}
              onKeyPress={(e) => handleKeyPress(e, 'label')}
              autoFocus
              className="text-center bg-transparent border-b"
            />
          ) : (
            data.label
          )}
        </div>

        {(data.type === 'account' || data.type === 'employee') && (
          <div
            onDoubleClick={() => handleDoubleClick('revenue')}
            className="text-sm"
          >
            {isEditingRevenue ? (
              <input
                type="number"
                defaultValue={data.revenue}
                onKeyPress={(e) => handleKeyPress(e, 'revenue')}
                autoFocus
                className="text-center bg-transparent border-b w-24"
              />
            ) : (
              `$${data.revenue.toLocaleString()}`
            )}
          </div>
        )}

        {data.type === 'segment' && (
          <div className="text-sm">
            ${data.revenue.toLocaleString()}
          </div>
        )}
      </div>

      <Handle type="source" position={Position.Bottom} />
    </div>
  );
}